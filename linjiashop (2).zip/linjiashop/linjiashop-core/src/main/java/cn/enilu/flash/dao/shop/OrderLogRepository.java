package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.OrderLog;
import cn.enilu.flash.dao.BaseRepository;


public interface OrderLogRepository extends BaseRepository<OrderLog,Long>{

}


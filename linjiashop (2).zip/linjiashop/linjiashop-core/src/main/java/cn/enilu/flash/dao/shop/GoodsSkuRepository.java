package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.GoodsSku;
import cn.enilu.flash.dao.BaseRepository;


public interface GoodsSkuRepository extends BaseRepository<GoodsSku,Long>{

}


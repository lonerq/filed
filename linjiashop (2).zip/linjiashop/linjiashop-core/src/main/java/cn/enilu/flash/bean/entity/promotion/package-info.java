/**
 * 推广相关实体
 * @author ：enilu
 * @date ：Created in 1/8/2020 8:16 PM
 */
package cn.enilu.flash.bean.entity.promotion;

package cn.enilu.flash.dao.promotion;


import cn.enilu.flash.bean.entity.promotion.Topic;
import cn.enilu.flash.dao.BaseRepository;


public interface TopicRepository extends BaseRepository<Topic,Long>{

}


package cn.enilu.flash.dao.shop;


import cn.enilu.flash.bean.entity.shop.Goods;
import cn.enilu.flash.dao.BaseRepository;


public interface GoodsRepository extends BaseRepository<Goods,Long>{

}


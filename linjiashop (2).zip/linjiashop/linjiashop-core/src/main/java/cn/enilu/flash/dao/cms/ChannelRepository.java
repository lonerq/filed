
package cn.enilu.flash.dao.cms;

import cn.enilu.flash.bean.entity.cms.Channel;
import cn.enilu.flash.dao.BaseRepository;

public interface ChannelRepository extends BaseRepository<Channel,Long> {
}
